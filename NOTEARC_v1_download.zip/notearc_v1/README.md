# NOTEARC v1 foundation

A static browser project for GitHub Pages. It currently supports:
- Responsive Japanese UI
- Importing and rendering MusicXML / score-partwise (uncompressed `.xml` / `.musicxml`)
- Parsing basic MusicXML note, rest, part, measure, pitch and duration data
- Browser playback using Tone.js synthesized timbres
- MusicXML export
- Image upload and validation before OMR

## Important current limitation
Image-to-notation OMR is **not implemented**. `src/omr.js` is an explicit integration boundary and reports that the recognition worker/model is missing. It does not guess notes from pixels. The current playback uses synthesized oscillator timbres, not sampled real instruments. PDF and compressed MXL imports are not supported yet. The MusicXML parser is a basic starting point and does not yet correctly handle every engraving convention, repeats, ties, tuplets, tempo directions, transposing instrument notation, or complex voices.

## Run locally
Open `index.html` from a local static server, for example:

```bash
python3 -m http.server 8000
```

Then visit `http://localhost:8000`.

## GitHub Pages
Upload the contents of this folder to the root of the `notearc` repository. In Settings → Pages, choose Deploy from a branch, `main`, `/ (root)`.

## External dependencies
OpenSheetMusicDisplay and Tone.js are loaded from jsDelivr CDN. Internet access is required. Review each dependency's licence and pin/self-host versions before public release.
