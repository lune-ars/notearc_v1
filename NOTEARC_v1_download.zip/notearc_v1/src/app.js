import {parseMusicXML,notesToTable} from './musicxml.js';
import {playNotes,stopPlayback} from './player.js';
import {recognizeImage} from './omr.js';
const $=id=>document.getElementById(id);
let selectedFiles=[],score=null,stopCurrent=null,osmd=null;
const fileInput=$('fileInput'),dropzone=$('dropzone');
function setStatus(message){$('appStatus').textContent=message;}
function refreshFiles(){ $('fileList').textContent=selectedFiles.length?selectedFiles.map(f=>`${f.name} (${Math.round(f.size/1024)} KB)`).join(' / '):'ファイルはまだ選択されていません。';$('recognizeBtn').disabled=!selectedFiles.some(f=>f.type.startsWith('image/')); }
function addFiles(files){selectedFiles=[...selectedFiles,...[...files].filter(f=>!selectedFiles.some(x=>x.name===f.name&&x.size===f.size))];refreshFiles();}
fileInput.addEventListener('change',e=>addFiles(e.target.files));
for(const ev of ['dragenter','dragover'])dropzone.addEventListener(ev,e=>{e.preventDefault();dropzone.classList.add('drag')});
for(const ev of ['dragleave','drop'])dropzone.addEventListener(ev,e=>{e.preventDefault();dropzone.classList.remove('drag')});
dropzone.addEventListener('drop',e=>addFiles(e.dataTransfer.files));
$('clearBtn').addEventListener('click',()=>{selectedFiles=[];score=null;fileInput.value='';refreshFiles();$('scoreView').innerHTML='<div class="empty">ここに読み込んだ楽譜が表示されます。</div>';$('notesTable').textContent='まだ認識データはありません。';$('recognitionStatus').textContent='画像の自動認識エンジンは未接続です。MusicXMLを読み込むと表示・再生できます。';$('playBtn').disabled=$('stopBtn').disabled=$('exportBtn').disabled=true;setStatus('準備完了');});
async function loadMusicXML(file){const xml=await file.text();score=parseMusicXML(xml);$('notesTable').innerHTML=notesToTable(score.notes);$('playBtn').disabled=score.notes.length===0;$('stopBtn').disabled=false;$('exportBtn').disabled=false;$('recognitionStatus').textContent=`MusicXMLを解析しました。${score.parts.length}パート、${score.notes.length}音符・休符、${score.measureCount}小節。`;setStatus('MusicXML読込済み');$('scoreView').innerHTML='';osmd=new opensheetmusicdisplay.OpenSheetMusicDisplay('scoreView',{autoResize:true,backend:'svg',drawTitle:true,drawPartNames:true});await osmd.load(xml);osmd.render();}
$('recognizeBtn').addEventListener('click',async()=>{const images=selectedFiles.filter(f=>f.type.startsWith('image/'));if(!images.length)return;try{setStatus('解析準備');for(const image of images){await recognizeImage(image,{onProgress:m=>$('recognitionStatus').textContent=m});}}catch(e){$('recognitionStatus').textContent=e.message;setStatus('認識エンジン未接続');}});
fileInput.addEventListener('change',async e=>{for(const f of e.target.files){if(/\.(musicxml|xml)$/i.test(f.name)||f.type==='application/vnd.recordare.musicxml+xml'||f.type==='application/xml'){try{await loadMusicXML(f)}catch(err){$('recognitionStatus').textContent=err.message;}}}});
$('tempo').addEventListener('input',e=>$('tempoValue').textContent=`♩ ${e.target.value}`);$('volume').addEventListener('input',e=>$('volumeValue').textContent=`${e.target.value}%`);
$('playBtn').addEventListener('click',async()=>{if(!score)return;try{$('playStatus').textContent='再生中…';$('playBtn').disabled=true;stopCurrent=await playNotes(score.notes,{tempo:Number($('tempo').value),volume:Number($('volume').value),instrument:$('instrument').value,onDone:()=>{$('playStatus').textContent='再生が終わりました。';$('playBtn').disabled=false;}});$('stopBtn').disabled=false;}catch(e){$('playStatus').textContent=e.message;$('playBtn').disabled=false;}});
$('stopBtn').addEventListener('click',()=>{if(stopCurrent)stopCurrent();else stopPlayback();stopCurrent=null;$('playStatus').textContent='停止しました。';$('playBtn').disabled=!score;$('stopBtn').disabled=true;});
$('exportBtn').addEventListener('click',()=>{if(!score)return;const blob=new Blob([score.xml],{type:'application/vnd.recordare.musicxml+xml'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='notearc-score.musicxml';a.click();URL.revokeObjectURL(url);});
