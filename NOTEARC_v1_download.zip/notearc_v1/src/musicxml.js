const text = (node, selector, fallback = '') => node.querySelector(selector)?.textContent?.trim() ?? fallback;
const durationMap = {1:4,2:2,4:1,8:.5,16:.25,32:.125,64:.0625};
export function parseMusicXML(xmlText){
  const doc = new DOMParser().parseFromString(xmlText,'application/xml');
  if(doc.querySelector('parsererror')) throw new Error('MusicXMLを読み取れませんでした。');
  const root=doc.documentElement;
  if(root.tagName!=='score-partwise') throw new Error('現在はscore-partwise形式のMusicXMLに対応しています。score-timewise形式は未対応です。')
  const parts=[...doc.querySelectorAll('part-list score-part')].map(p=>({id:p.getAttribute('id'),name:text(p,'part-name','パート')}));
  const parsed=[];
  for(const part of [...doc.querySelectorAll('score-partwise > part')]){
    const meta=parts.find(p=>p.id===part.getAttribute('id'))||{id:part.id,name:part.id};
    let divisions=1,beats=4,beatType=4,measureNo=0,transpose=0;
    for(const measure of [...part.querySelectorAll(':scope > measure')]){
      measureNo++;
      const attr=measure.querySelector('attributes');
      if(attr){divisions=Number(text(attr,'divisions',divisions))||divisions;beats=Number(text(attr,'time beats',beats))||beats;beatType=Number(text(attr,'time beat-type',beatType))||beatType;transpose=Number(text(attr,'transpose chromatic',transpose))||transpose;}
      let cursor=0;
      for(const item of [...measure.children]){
        if(item.tagName==='backup'){cursor-=Number(text(item,'duration','0'))/divisions;continue;}
        if(item.tagName==='forward'){cursor+=Number(text(item,'duration','0'))/divisions;continue;}
        if(item.tagName!=='note')continue;
        const isChord=!!item.querySelector('chord');
        const dur=Number(text(item,'duration','0'))/divisions;
        const rest=!!item.querySelector('rest');
        const step=text(item,'pitch step','C'),oct=Number(text(item,'pitch octave','4'));
        const alter=Number(text(item,'pitch alter','0'));
        const accidental=Number(text(item,'pitch alter','0'));
        const midi=rest?null:(oct+1)*12+({C:0,D:2,E:4,F:5,G:7,A:9,B:11}[step]??0)+alter+transpose;
        const type=text(item,'type','');
        const base=durationMap[Number(text(item,'type','').replace('whole','1').replace('half','2').replace('quarter','4').replace('eighth','8').replace('16th','16').replace('32nd','32').replace('64th','64'))]??dur;
        const dots=item.querySelectorAll('dot').length;
        const dotted=base*(dots===1?1.5:dots===2?1.75:dots===3?1.875:1);
        const note={partId:meta.id,partName:meta.name,measure:measureNo,beat:cursor,step,octave:oct,alter,midi,durationQuarter:dur||dotted||1,type,rest,voice:text(item,'voice','1'),staff:text(item,'staff','1'),dots,accidental,lyrics:text(item,'lyric text','')};
        parsed.push(note);
        if(!isChord)cursor+=dur;
      }
    }
  }
  return {parts,notes:parsed,xml:xmlText,measureCount:Math.max(0,...parsed.map(n=>n.measure))};
}
export function notesToTable(notes){
  if(!notes.length)return '<p class="empty">MusicXML内に音符データが見つかりません。</p>';
  const rows=notes.slice(0,500).map((n,i)=>`<tr><td>${i+1}</td><td>${escapeHtml(n.partName)}</td><td>${n.measure}</td><td>${n.rest?'休符':escapeHtml(n.step+(n.alter===1?'♯':n.alter===-1?'♭':'')+n.octave)}</td><td>${n.durationQuarter}</td><td>${n.rest?'—':n.midi}</td></tr>`).join('');
  return `<div style="overflow:auto"><table><thead><tr><th>#</th><th>パート</th><th>小節</th><th>音</th><th>長さ(四分音符)</th><th>MIDI</th></tr></thead><tbody>${rows}</tbody></table></div>`;
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
