/*
 * OMR adapter boundary.
 * This project deliberately does not pretend that staff-line heuristics are a full OMR engine.
 * A real integration must supply a compatible worker + model files and return MusicXML.
 */
export async function recognizeImage(file,{onProgress=()=>{}}={}){
  onProgress('画像を準備しています…');
  if(!file || !file.type.startsWith('image/')) throw new Error('画像ファイルを選択してください。');
  // Check that the browser can decode the image before handing it to an OMR worker.
  const bitmap=await createImageBitmap(file);
  const info={width:bitmap.width,height:bitmap.height};
  bitmap.close();
  throw new Error(`画像は読み込めました（${info.width}×${info.height}）。ただし、NOTEARC用のOMRモデル／Workerがまだ組み込まれていないため、音符・リズムの自動認識は実行できません。`);
}
