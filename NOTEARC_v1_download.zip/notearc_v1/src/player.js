let synth=null, events=[], scheduled=[];
const instrumentSettings={piano:{osc:'triangle',attack:.005,release:.35,filter:6000},flute:{osc:'sine',attack:.08,release:.2,filter:5000},clarinet:{osc:'square',attack:.03,release:.15,filter:2400},trumpet:{osc:'sawtooth',attack:.025,release:.12,filter:3200},strings:{osc:'sawtooth',attack:.12,release:.35,filter:4200}};
export async function playNotes(notes,{tempo=100,volume=70,instrument='piano',onDone=()=>{}}={}){
  await Tone.start(); stopPlayback();
  const cfg=instrumentSettings[instrument]||instrumentSettings.piano;
  synth=new Tone.PolySynth(Tone.Synth,{oscillator:{type:cfg.osc},envelope:{attack:cfg.attack,decay:.1,sustain:.65,release:cfg.release}}).toDestination();
  synth.volume.value=20*Math.log10(Math.max(.001,volume/100));
  const quarter=60/tempo;
  const playable=notes.filter(n=>!n.rest&&Number.isFinite(n.midi));
  if(!playable.length)throw new Error('再生できる音符がありません。');
  const start=Tone.now()+.15;
  for(const n of playable){
    const seconds=Math.max(.08,(Number(n.durationQuarter)||1)*quarter);
    const time=start+(Math.max(0,n.measure-1)*4+(Number(n.beat)||0))*quarter;
    const id=synth.triggerAttackRelease(Tone.Frequency(n.midi,'midi'),seconds,time);
    scheduled.push(id);
  }
  const last=Math.max(...playable.map(n=>(Math.max(0,n.measure-1)*4+(Number(n.beat)||0)+(Number(n.durationQuarter)||1))*quarter));
  const timer=setTimeout(()=>{onDone();},(last+.5)*1000);
  return ()=>{clearTimeout(timer);stopPlayback();};
}
export function stopPlayback(){if(synth){try{synth.releaseAll();synth.dispose()}catch{}synth=null;}scheduled=[];}
